import Coccinella from './Coccinella.jpg'
import ConvergentLadyBeetle from './ConvergentLadyBeetle.jpg'
import FourteenSpottedLadybug from './FourteenSpottedLadybug.jpg'
import PslloboraVigintiduopunctata from './PsylloboraVigintiduopunctata.jpg'
import TwoSpotLadybird from './TwoSpotLadybird.jpg'

export default {
    Coccinella,
    ConvergentLadyBeetle,
    FourteenSpottedLadybug,
    PslloboraVigintiduopunctata,
    TwoSpotLadybird,
}
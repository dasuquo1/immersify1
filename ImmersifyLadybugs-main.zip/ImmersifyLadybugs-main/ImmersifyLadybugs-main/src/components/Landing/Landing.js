import React from 'react'

import { GetLadybugs } from '../Utils/getLadybugs'
import { DisplayContent } from './DisplayContent/DisplayContent'

export const Landing = () => {

    GetLadybugs(gotDataCallback)

    function gotDataCallback (data) {
        //console.log(data)
    }

    return (
        <>
            <h1>Landing Page</h1>

            <DisplayContent
                names={["Ladybug1", "Ladybug2", "Ladybug3"]}
                 const obj = {JSON.parse(names)}
                imageLocations={[
                    "Coccinella.jpg",
                    "image2.jpg",
                    "image3.jpg",
                ]}
                const bugLocation = {
                    name1 : 'Ladybug1'
                    name2: 'Ladybug2',
                    name3 : 'Ladybug3',
                    location1 : 'Coccinella.jpg',  
                    location1 : 'image2.jpg',
                    location3 : 'image3.jpg',
                }
               
            />
        </>
    );
}